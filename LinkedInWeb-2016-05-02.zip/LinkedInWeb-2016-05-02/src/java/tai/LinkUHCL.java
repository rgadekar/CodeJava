/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tai;

import java.util.* ;

import org.json.JSONArray;
import org.json.JSONObject;
/**
 *
 * @author luongt7640
 */
public class LinkUHCL {

    static Scanner input = new Scanner ( System.in );
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        
        
    }
}
